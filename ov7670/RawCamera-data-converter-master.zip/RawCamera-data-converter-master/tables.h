extern const uint8_t sqrt_tab[];
extern const uint8_t sine_tab[];
